local password = '3xTMAfVB'

local sampev = require("samp.events")
require("addon")
local requests = require("requests")
local effil = require 'effil'

function sampev.onShowDialog(id, style, title, btn1, btn2, text)
	if title:find('�����������') then
		sendDialogResponse(id, 1, 0, password)
		return false
	end
end