-- author: _raz0r
-- telegram: t.me/razor_code

local samp = require("samp/events")

function onLoad()
    print("Launcher Emulator loaded. Author: _raz0r / telegram: t.me/razor_code")
    print("��������� ��� RakSAMP -- fezikige")
end

function samp.onSendClientJoin(version, mod, nickname, challengeResponse, joinAuthKey, clientVer, challengeResponse2)
    sendGamePath()
end

function sendGamePath()
    local server_ip, port = getServerAddress():match("(.*):(.*)")
    local player_name = getBotNick()
    local game_path = string.format("\"C:\\Arizona\\bin\\arizona\\gta_sa.exe\" -c -h %s -p %d -n %s -mem 2048 -x -seasons -enable_grass -arizona", server_ip, port, player_name)
    print("Fake game path: " .. game_path)
    local bs = bitStream.new()
    bs:writeInt8(220)
    bs:writeInt8(140)
    bs:writeInt32(#game_path)
    bs:writeString(game_path)
    bs:writeInt8(0)
    bs:sendPacket()
    bs:reset()
    print("Game path sended!")
end